---Original API created by the creators of FCEUX.
---Some documentation for this document taken from http://fceux.com/web/help/fceux.html?LuaFunctionsList.html
---This document created by Connor Bell.
---@author Connor Bell
--@module emu Contains functions for interacting with the emulator.
require(emu)

---Executes a power cycle.
function emu.poweron()
end